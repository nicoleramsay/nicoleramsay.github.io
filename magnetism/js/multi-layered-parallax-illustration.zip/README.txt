A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/YVjeZY.

 Tutorial:
https://medium.com/@PatrykZabielski/how-to-make-multi-layered-parallax-illustration-with-css-javascript-2b56883c3f27